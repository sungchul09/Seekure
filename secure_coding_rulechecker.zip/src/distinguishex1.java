import java.io.FileInputStream;
import java.io.IOException;

public class distinguishex1 {
		public static void main(String[] args) throws IOException {
		
			FileInputStream in = null;
		
			// Initialize stream 
		
			byte data;
		
			while ((data = (byte) in.read()) != -1) { 
		
			
				// ... 
				}
			}
		
}
